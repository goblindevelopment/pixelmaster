# AutoGear

## [2023-11-16-release](https://github.com/AlexFolland/AutoGear/tree/2023-11-16-release) (2023-11-17)
[Full Changelog](https://github.com/AlexFolland/AutoGear/compare/2023-08-30-release-3...2023-11-16-release) [Previous Releases](https://github.com/AlexFolland/AutoGear/releases)

- fix gear slots remaining locked while slot-locking is disabled  
